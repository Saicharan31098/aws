
import json
import logging
import boto3

sns = boto3.client("sns")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Demo user credentials
users = {
    "admin": "Bank@123",
    "user1": "User@123"
}

# Track failed login attempts
failed_attempts = {}

# SNS topic ARN
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:489612427942:SecureBankAlerts"


def lambda_handler(event, context):
    username = event.get("username")
    password = event.get("password")

    if not username or not password:
        logger.warning("Login request missing credentials")
        return {
            "statusCode": 400,
            "body": json.dumps({
                "message": "Username and password are required"
            })
        }

    # Validate credentials
    if username in users and users[username] == password:
        failed_attempts[username] = 0

        logger.info("Successful login for user: %s", username)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Authorized login",
                "status": "SUCCESS"
            })
        }

    # Record failed attempt
    failed_attempts[username] = failed_attempts.get(username, 0) + 1

    logger.warning(
        "Failed login for user: %s | Attempt: %d",
        username,
        failed_attempts[username]
    )

    # Detect suspicious activity
    if failed_attempts[username] >= 3:
        logger.error(
            "Suspicious activity detected for user: %s",
            username
        )

        # Send SNS notification
        try:
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="Security Alert: Suspicious Login",
                Message=(
                    f"Suspicious login activity detected for user: {username}. "
                    f"Failed attempts: {failed_attempts[username]}"
                )
            )
            logger.info("SNS alert sent for user: %s", username)

        except Exception:
            logger.exception("Failed to send SNS alert")

        return {
            "statusCode": 403,
            "body": json.dumps({
                "message": "Suspicious activity detected",
                "status": "ALERT"
            })
        }

    # Normal invalid credentials response
    return {
        "statusCode": 401,
        "body": json.dumps({
            "message": "Invalid credentials",
            "status": "FAILED"
        })
    }
